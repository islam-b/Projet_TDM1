
package com.example.projettdm1.adapters
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import com.example.projettdm1.R
import com.example.projettdm1.models.Categorie

class CategoriesListAdapter(val categories: ArrayList<Categorie>): RecyclerView.Adapter<CategoriesListAdapter.ViewHolder>() {


    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): ViewHolder {
        val vi = LayoutInflater.from(p0.context).inflate(R.layout.category_item, p0, false)
        return ViewHolder(vi)
    }

    override fun getItemCount(): Int {
        return categories.size
    }

    override fun onBindViewHolder(p0: ViewHolder, p1: Int) {
        val category = categories[p1]
        p0.icon.setImageResource(category.imageRes)
        p0.title.text = category.Title
        p0.description.text = category.Description

    }


    inner class ViewHolder(itemView: View): RecyclerView.ViewHolder(itemView) {
        val icon=itemView.findViewById<ImageView>(R.id.category_icon)
        val title= itemView.findViewById<TextView>(R.id.category_title)
        val description = itemView.findViewById<TextView>(R.id.category_decription)
    }
}