package com.example.projettdm1.models

class News(iconRes: Int, date: String, description: String, categorie:Categorie) {
    val iconRes = iconRes
    val date = date
    val description = description
    val categorie = categorie
}