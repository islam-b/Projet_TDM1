
package com.example.projettdm1.adapters
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import com.example.projettdm1.R
import com.example.projettdm1.models.Categorie
import com.example.projettdm1.models.News

class NewsListAdapter(val news: ArrayList<News>): RecyclerView.Adapter<NewsListAdapter.ViewHolder>() {


    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): ViewHolder {
        val vi = LayoutInflater.from(p0.context).inflate(R.layout.news_item, p0, false)
        return ViewHolder(vi)
    }

    override fun getItemCount(): Int {
        return news.size
    }

    override fun onBindViewHolder(p0: ViewHolder, p1: Int) {
        val new = news[p1]
        p0.icon.setImageResource(new.iconRes)
        p0.description.text = new.description
        p0.date.text = new.date
        p0.categorie.text = new.categorie.Title
        //add event handler for the heart

    }


    inner class ViewHolder(itemView: View): RecyclerView.ViewHolder(itemView) {
        val icon=itemView.findViewById<ImageView>(R.id.news_icon)
        val description= itemView.findViewById<TextView>(R.id.news_description)
        val date= itemView.findViewById<TextView>(R.id.news_date)
        val categorie= itemView.findViewById<TextView>(R.id.news_category)
    }
}