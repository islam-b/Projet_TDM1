package com.example.projettdm1.models

import android.util.EventLogTags

class Categorie(imageRes: Int, Title: String, Description: String) {
    val imageRes = imageRes
    val Title = Title
    val Description = Description
}